import { User, InsertUser, Customer, InsertCustomer, Activity, InsertActivity, MessageLog, InsertMessageLog, ImportExportLog, InsertImportExportLog } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

// Define the storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Customer methods
  getCustomer(id: number): Promise<Customer | undefined>;
  getAllCustomers(): Promise<Customer[]>;
  getCustomersByStatus(status: string): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: InsertCustomer): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;

  // Activity methods
  getRecentActivities(limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Message logs
  getMessagesByPlatform(platform: string): Promise<MessageLog[]>;
  createMessageLog(log: InsertMessageLog): Promise<MessageLog>;

  // Import/Export logs
  getImportExportLogs(): Promise<ImportExportLog[]>;
  createImportExportLog(log: InsertImportExportLog): Promise<ImportExportLog>;

  // Stats
  getStats(): Promise<any>;
  
  // Session store
  sessionStore: any; // Usando any para evitar problemas de tipagem com SessionStore
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private customers: Map<number, Customer>;
  private activities: Activity[];
  private messageLogs: MessageLog[];
  private importExportLogs: ImportExportLog[];
  
  sessionStore: any;
  currentUserId: number;
  currentCustomerId: number;
  currentActivityId: number;
  currentMessageLogId: number;
  currentImportExportLogId: number;

  constructor() {
    this.users = new Map();
    this.customers = new Map();
    this.activities = [];
    this.messageLogs = [];
    this.importExportLogs = [];
    
    this.currentUserId = 1;
    this.currentCustomerId = 1;
    this.currentActivityId = 1;
    this.currentMessageLogId = 1;
    this.currentImportExportLogId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Create a default admin user
    this.createUser({
      username: "admin",
      password: "password", // This will be hashed in the auth service
      name: "Admin User",
      email: "admin@example.com"
    });
    
    // Add sample customers
    this.createSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    // Garantindo que todos os campos opcionais sejam inicializados como null se não fornecidos
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      name: insertUser.name || null,
      email: insertUser.email || null
    };
    this.users.set(id, user);
    return user;
  }

  // Customer methods
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getAllCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomersByStatus(status: string): Promise<Customer[]> {
    return Array.from(this.customers.values()).filter(
      (customer) => customer.status === status
    );
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const now = new Date();
    // Garantindo que todos os campos opcionais sejam inicializados como null se não fornecidos
    const customer: Customer = { 
      id,
      firstName: insertCustomer.firstName,
      lastName: insertCustomer.lastName,
      email: insertCustomer.email,
      phone: insertCustomer.phone,
      city: insertCustomer.city || null,
      country: insertCustomer.country || null,
      source: insertCustomer.source || null,
      notes: insertCustomer.notes || null,
      status: insertCustomer.status || null,
      createdAt: now,
      lastContact: insertCustomer.lastContact || now
    };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, customer: InsertCustomer): Promise<Customer | undefined> {
    const existingCustomer = this.customers.get(id);
    if (!existingCustomer) {
      return undefined;
    }
    
    const updatedCustomer: Customer = {
      ...existingCustomer,
      ...customer
    };
    
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }

  async deleteCustomer(id: number): Promise<boolean> {
    return this.customers.delete(id);
  }

  // Activity methods
  async getRecentActivities(limit: number = 10): Promise<Activity[]> {
    return this.activities
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const now = new Date();
    const activity: Activity = {
      ...insertActivity,
      id,
      timestamp: insertActivity.timestamp || now
    };
    
    this.activities.push(activity);
    return activity;
  }

  // Message logs
  async getMessagesByPlatform(platform: string): Promise<MessageLog[]> {
    return this.messageLogs
      .filter(log => log.platform === platform)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createMessageLog(insertLog: InsertMessageLog): Promise<MessageLog> {
    const id = this.currentMessageLogId++;
    const now = new Date();
    const log: MessageLog = {
      ...insertLog,
      id,
      timestamp: insertLog.timestamp || now
    };
    
    this.messageLogs.push(log);
    return log;
  }

  // Import/Export logs
  async getImportExportLogs(): Promise<ImportExportLog[]> {
    return this.importExportLogs
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createImportExportLog(insertLog: InsertImportExportLog): Promise<ImportExportLog> {
    const id = this.currentImportExportLogId++;
    const now = new Date();
    const log: ImportExportLog = {
      ...insertLog,
      id,
      timestamp: insertLog.timestamp || now
    };
    
    this.importExportLogs.push(log);
    return log;
  }

  // Stats
  async getStats(): Promise<any> {
    const totalCustomers = this.customers.size;
    const activeCustomers = Array.from(this.customers.values()).filter(
      (customer) => customer.status === "active"
    ).length;
    
    const activeCampaigns = 7; // Mocked for MVP
    const engagementRate = 68; // Mocked for MVP
    
    return {
      totalCustomers,
      activeCustomers,
      activeCampaigns,
      engagementRate
    };
  }

  // Helper method to add sample data for demo purposes
  private createSampleData() {
    // Sample customers
    const sampleCustomers: InsertCustomer[] = [
      {
        firstName: "Maria",
        lastName: "Silva",
        email: "maria.silva@example.com",
        phone: "+55 11 98765-4321",
        city: "São Paulo",
        country: "Brazil",
        source: "website",
        notes: "Interested in premium plan",
        status: "active",
        lastContact: new Date(2023, 9, 15) // Oct 15, 2023
      },
      {
        firstName: "João",
        lastName: "Santos",
        email: "joao.santos@example.com",
        phone: "+55 11 99876-5432",
        city: "Rio de Janeiro",
        country: "Brazil",
        source: "referral",
        notes: "Referred by Maria Silva",
        status: "active",
        lastContact: new Date(2023, 9, 12) // Oct 12, 2023
      },
      {
        firstName: "Ana",
        lastName: "Costa",
        email: "ana.costa@example.com",
        phone: "+55 11 97654-3210",
        city: "Curitiba",
        country: "Brazil",
        source: "social",
        notes: "Found us on Instagram",
        status: "pending",
        lastContact: new Date(2023, 9, 5) // Oct 5, 2023
      }
    ];
    
    for (const customer of sampleCustomers) {
      this.createCustomer(customer);
    }
    
    // Sample activities
    const sampleActivities: InsertActivity[] = [
      {
        type: "new_customer",
        description: "Maria Silva was added to your customer database",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
      },
      {
        type: "campaign",
        description: "Summer promotion campaign was sent to 450 customers",
        timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000) // 5 hours ago
      },
      {
        type: "whatsapp",
        description: "WhatsApp business account connected successfully",
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
      }
    ];
    
    for (const activity of sampleActivities) {
      this.createActivity(activity);
    }
    
    // Sample message logs
    const sampleWhatsAppLogs: InsertMessageLog[] = [
      {
        platform: "whatsapp",
        recipientName: "Maria Silva",
        recipientId: "1",
        messageType: "single",
        messagePreview: "Hello Maria, thank you for your recent purchase!",
        status: "delivered",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
      },
      {
        platform: "whatsapp",
        recipientName: "João Santos",
        recipientId: "2",
        messageType: "template",
        messagePreview: "[Appointment Reminder] Hello João, this is a reminder about your upcoming appointment",
        status: "read",
        timestamp: new Date(Date.now() - 20 * 60 * 60 * 1000) // 20 hours ago
      }
    ];
    
    for (const log of sampleWhatsAppLogs) {
      this.createMessageLog(log);
    }
    
    // Sample Instagram messages
    const sampleInstagramLogs: InsertMessageLog[] = [
      {
        platform: "instagram",
        recipientName: "@johndoe",
        recipientId: "john.doe",
        messageType: "direct",
        messagePreview: "Hi there! I'm interested in your products. Do you ship internationally?",
        status: "unread",
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000) // 3 hours ago
      },
      {
        platform: "instagram",
        recipientName: "@amysmith",
        recipientId: "amy.smith",
        messageType: "direct",
        messagePreview: "Thanks for your quick response! I'll place my order today.",
        status: "replied",
        timestamp: new Date(Date.now() - 22 * 60 * 60 * 1000) // 22 hours ago
      }
    ];
    
    for (const log of sampleInstagramLogs) {
      this.createMessageLog(log);
    }
    
    // Sample import/export logs
    const sampleImportExportLogs: InsertImportExportLog[] = [
      {
        type: "import",
        fileName: "new_customers_oct.csv",
        recordCount: 45,
        status: "complete",
        timestamp: new Date(2023, 9, 15, 9, 45) // Oct 15, 2023, 09:45
      },
      {
        type: "export",
        fileName: "active_customers.xlsx",
        recordCount: 987,
        status: "complete",
        timestamp: new Date(2023, 9, 12, 14, 22) // Oct 12, 2023, 14:22
      }
    ];
    
    for (const log of sampleImportExportLogs) {
      this.createImportExportLog(log);
    }
  }
}

export const storage = new MemStorage();
