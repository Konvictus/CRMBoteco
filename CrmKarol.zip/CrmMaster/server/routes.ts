import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertCustomerSchema, insertActivitySchema, insertMessageLogSchema, insertImportExportLogSchema } from "@shared/schema";
import multer from "multer";
import * as XLSX from "xlsx";
import { Parser } from "json2csv";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Middleware to check if user is authenticated
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Customer routes
  app.get("/api/customers", requireAuth, async (req, res) => {
    try {
      const customers = await storage.getAllCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.post("/api/customers", requireAuth, async (req, res) => {
    try {
      const validatedData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(validatedData);
      
      // Log the activity
      await storage.createActivity({
        type: "new_customer",
        description: `New customer added: ${customer.firstName} ${customer.lastName}`,
      });
      
      res.status(201).json(customer);
    } catch (error) {
      res.status(400).json({ message: "Invalid customer data" });
    }
  });

  app.put("/api/customers/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCustomerSchema.parse(req.body);
      const customer = await storage.updateCustomer(id, validatedData);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.json(customer);
    } catch (error) {
      res.status(400).json({ message: "Invalid customer data" });
    }
  });

  app.delete("/api/customers/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCustomer(id);
      
      if (!success) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Activity routes
  app.get("/api/activities", requireAuth, async (req, res) => {
    try {
      const activities = await storage.getRecentActivities();
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  app.post("/api/activities", requireAuth, async (req, res) => {
    try {
      const validatedData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(validatedData);
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid activity data" });
    }
  });

  // Dashboard statistics
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Import/Export routes
  app.post("/api/import", requireAuth, upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const fileBuffer = req.file.buffer;
      const filename = req.file.originalname;
      
      // Process Excel or CSV file
      const workbook = XLSX.read(fileBuffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(sheet);
      
      // Validate and transform data
      const customers = [];
      for (const row of data) {
        try {
          // Map spreadsheet columns to customer fields
          const customer = {
            firstName: row.firstName || row.first_name || "",
            lastName: row.lastName || row.last_name || "",
            email: row.email || "",
            phone: row.phone || row.phoneNumber || row.phone_number || "",
            city: row.city || "",
            country: row.country || "",
            source: row.source || "import",
            notes: row.notes || "",
            status: row.status || "active",
          };
          
          // Validate required fields
          if (!customer.firstName || !customer.lastName || !customer.email || !customer.phone) {
            continue; // Skip invalid rows
          }
          
          const validatedData = insertCustomerSchema.parse(customer);
          const newCustomer = await storage.createCustomer(validatedData);
          customers.push(newCustomer);
        } catch (error) {
          // Skip invalid rows
          continue;
        }
      }
      
      // Log import activity
      const log = await storage.createImportExportLog({
        type: "import",
        fileName: filename,
        recordCount: customers.length,
        status: "complete",
      });
      
      // Create activity
      await storage.createActivity({
        type: "import",
        description: `Imported ${customers.length} customers from ${filename}`,
      });
      
      res.status(201).json({ 
        message: `Successfully imported ${customers.length} customers`,
        log
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to import file" });
    }
  });

  app.get("/api/export", requireAuth, async (req, res) => {
    try {
      const format = req.query.format || "csv";
      const type = req.query.type || "all";
      const logId = req.query.logId ? parseInt(req.query.logId as string, 10) : null;
      
      // Get customers based on type
      let customers;
      if (type === "active") {
        customers = await storage.getCustomersByStatus("active");
      } else {
        customers = await storage.getAllCustomers();
      }
      
      let data;
      let filename;
      let contentType;
      
      // Se um log ID for fornecido, tente reutilizar o nome do arquivo desse log
      let existingFileName;
      if (logId) {
        const logs = await storage.getImportExportLogs();
        const log = logs.find(l => l.id === logId);
        if (log) {
          existingFileName = log.fileName;
        }
      }
      
      if (format === "xlsx") {
        // Convert to Excel
        const worksheet = XLSX.utils.json_to_sheet(customers);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Customers");
        
        const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
        data = buffer;
        filename = existingFileName && existingFileName.endsWith('.xlsx') 
          ? existingFileName 
          : `customers_export_${Date.now()}.xlsx`;
        contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      } else {
        // Convert to CSV
        const parser = new Parser({ fields: Object.keys(customers[0] || {}) });
        data = parser.parse(customers);
        filename = existingFileName && existingFileName.endsWith('.csv') 
          ? existingFileName 
          : `customers_export_${Date.now()}.csv`;
        contentType = "text/csv";
      }
      
      // Log export activity apenas se não for um redownload de um arquivo existente
      if (!logId) {
        await storage.createImportExportLog({
          type: "export",
          fileName: filename,
          recordCount: customers.length,
          status: "complete",
        });
        
        // Create activity
        await storage.createActivity({
          type: "export",
          description: `Exported ${customers.length} customers to ${filename}`,
        });
      }
      
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Content-Type", contentType);
      res.send(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  app.get("/api/importexport/logs", requireAuth, async (req, res) => {
    try {
      const logs = await storage.getImportExportLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch import/export logs" });
    }
  });

  // WhatsApp routes (mocked for MVP)
  app.post("/api/whatsapp/send", requireAuth, async (req, res) => {
    try {
      const { recipient, messageType, messageText } = req.body;
      
      if (!recipient || !messageText) {
        return res.status(400).json({ message: "Recipient and message text are required" });
      }
      
      // In a real implementation, this would integrate with WhatsApp API
      // For the MVP, we'll just log the message
      const messageLog = await storage.createMessageLog({
        platform: "whatsapp",
        recipientName: recipient.name,
        recipientId: recipient.id,
        messageType: messageType || "single",
        messagePreview: messageText.substring(0, 50) + (messageText.length > 50 ? "..." : ""),
        status: "delivered",
      });
      
      // Create activity
      await storage.createActivity({
        type: "whatsapp",
        description: `WhatsApp message sent to ${recipient.name}`,
      });
      
      res.status(201).json({ 
        message: "Message sent successfully",
        log: messageLog
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to send WhatsApp message" });
    }
  });

  app.get("/api/whatsapp/messages", requireAuth, async (req, res) => {
    try {
      const messages = await storage.getMessagesByPlatform("whatsapp");
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch WhatsApp messages" });
    }
  });

  // Instagram routes (mocked for MVP)
  app.post("/api/instagram/send", requireAuth, async (req, res) => {
    try {
      const { recipient, messageText } = req.body;
      
      if (!recipient || !messageText) {
        return res.status(400).json({ message: "Recipient and message text are required" });
      }
      
      // In a real implementation, this would integrate with Instagram API
      // For the MVP, we'll just log the message
      const messageLog = await storage.createMessageLog({
        platform: "instagram",
        recipientName: recipient.name,
        recipientId: recipient.id,
        messageType: "direct",
        messagePreview: messageText.substring(0, 50) + (messageText.length > 50 ? "..." : ""),
        status: "sent",
      });
      
      // Create activity
      await storage.createActivity({
        type: "instagram",
        description: `Instagram message sent to ${recipient.name}`,
      });
      
      res.status(201).json({ 
        message: "Message sent successfully",
        log: messageLog
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to send Instagram message" });
    }
  });

  app.get("/api/instagram/messages", requireAuth, async (req, res) => {
    try {
      const messages = await storage.getMessagesByPlatform("instagram");
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch Instagram messages" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
