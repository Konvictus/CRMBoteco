import Layout from "@/components/layout/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function SettingsPage() {
  return (
    <Layout>
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Settings</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">General Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="notifications" className="block font-medium mb-1">Email Notifications</Label>
                    <p className="text-sm text-gray-500">Receive email notifications about customer activities</p>
                  </div>
                  <Switch id="notifications" />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="darkMode" className="block font-medium mb-1">Dark Mode</Label>
                    <p className="text-sm text-gray-500">Enable dark mode for the interface</p>
                  </div>
                  <Switch id="darkMode" />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="autoArchive" className="block font-medium mb-1">Auto Archive</Label>
                    <p className="text-sm text-gray-500">Automatically archive inactive customers after 90 days</p>
                  </div>
                  <Switch id="autoArchive" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Account Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="block font-medium mb-1">Change Password</Label>
                  <p className="text-sm text-gray-500 mb-4">Update your account password</p>
                  <Button>Change Password</Button>
                </div>
                
                <Separator />
                
                <div>
                  <Label className="block font-medium mb-1">Export Your Data</Label>
                  <p className="text-sm text-gray-500 mb-4">Download all your account data</p>
                  <Button variant="outline">Export Data</Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Subscription</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="text-sm font-semibold">Current Plan</div>
                  <div className="text-xl font-bold text-primary">Business</div>
                </div>
                
                <div className="space-y-2 text-sm mb-6">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Renewal Date</span>
                    <span className="font-medium">Jan 15, 2026</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Monthly Price</span>
                    <span className="font-medium">$49.99</span>
                  </div>
                </div>
                
                <Button className="w-full">Manage Subscription</Button>
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Storage Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-2">
                  <div className="h-2 bg-gray-200 rounded-full">
                    <div className="h-2 bg-primary rounded-full w-3/4"></div>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  <span className="font-medium">750MB</span> of 1GB used
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}