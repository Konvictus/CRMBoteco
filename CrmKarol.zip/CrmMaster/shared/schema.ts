import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
});

export const loginUserSchema = insertUserSchema.pick({
  username: true,
  password: true,
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  city: text("city"),
  country: text("country"),
  source: text("source"),
  notes: text("notes"),
  status: text("status").default("active"),
  lastContact: timestamp("last_contact"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  description: text("description").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
});

export const messageLogs = pgTable("message_logs", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(), // "whatsapp" or "instagram"
  recipientName: text("recipient_name").notNull(),
  recipientId: text("recipient_id").notNull(),
  messageType: text("message_type").notNull(),
  messagePreview: text("message_preview").notNull(),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertMessageLogSchema = createInsertSchema(messageLogs).omit({
  id: true,
});

export const importExportLogs = pgTable("import_export_logs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // "import" or "export"
  fileName: text("file_name").notNull(),
  recordCount: integer("record_count").notNull(),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertImportExportLogSchema = createInsertSchema(importExportLogs).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type MessageLog = typeof messageLogs.$inferSelect;
export type InsertMessageLog = z.infer<typeof insertMessageLogSchema>;

export type ImportExportLog = typeof importExportLogs.$inferSelect;
export type InsertImportExportLog = z.infer<typeof insertImportExportLogSchema>;
