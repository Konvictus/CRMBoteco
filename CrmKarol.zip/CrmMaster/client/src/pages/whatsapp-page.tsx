import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Loader2, Paperclip, Check } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import { Customer, MessageLog } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function WhatsAppPage() {
  const [messageType, setMessageType] = useState("single");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [messageText, setMessageText] = useState("Hello {customer_name}, thank you for your recent purchase! We hope you're enjoying your new product. Please let us know if you have any questions.");
  const { toast } = useToast();

  const { data: customers, isLoading: isLoadingCustomers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const { data: messages, isLoading: isLoadingMessages } = useQuery<MessageLog[]>({
    queryKey: ["/api/whatsapp/messages"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { recipient: any, messageType: string, messageText: string }) => {
      const res = await apiRequest("POST", "/api/whatsapp/send", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Your WhatsApp message has been sent successfully.",
      });

      setMessageText("");

      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send WhatsApp message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!selectedCustomer) {
      toast({
        title: "Error",
        description: "Please select a recipient.",
        variant: "destructive",
      });
      return;
    }

    if (!messageText) {
      toast({
        title: "Error",
        description: "Please enter a message.",
        variant: "destructive",
      });
      return;
    }

    const customer = customers?.find(c => c.id.toString() === selectedCustomer);
    if (!customer) return;

    const recipient = {
      id: customer.id.toString(),
      name: `${customer.firstName} ${customer.lastName}`,
      phone: customer.phone,
    };

    sendMessageMutation.mutate({
      recipient,
      messageType,
      messageText: messageText.replace(
        "{customer_name}",
        customer.firstName
      ),
    });
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "read":
        return "bg-green-100 text-green-800";
      case "sent":
        return "bg-blue-100 text-blue-800";
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeBadgeClass = (type: string) => {
    switch (type) {
      case "single":
        return "bg-blue-100 text-blue-800";
      case "template":
        return "bg-purple-100 text-purple-800";
      case "campaign":
        return "bg-indigo-100 text-indigo-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">WhatsApp Integration</h1>
        <p className="text-gray-600">Connect with your customers via WhatsApp messaging</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">WhatsApp Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-600">Monthly Message Limit</div>
                <div className="text-sm font-medium text-gray-900">1,000</div>
              </div>
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-600">Messages Sent (This Month)</div>
                <div className="text-sm font-medium text-gray-900">342</div>
              </div>
            </div>

            <div className="border-t border-gray-200 mt-6 pt-6">
              <Button variant="link" className="p-0 h-auto text-primary">
                <span className="mr-2">⚙️</span> Manage WhatsApp Settings
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Send WhatsApp Message</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Message Type</label>
                <Select value={messageType} onValueChange={setMessageType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select message type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single Customer</SelectItem>
                    <SelectItem value="template">Template Message</SelectItem>
                    <SelectItem value="campaign">Campaign</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Select Customer</label>
                <Select value={selectedCustomer} onValueChange={setSelectedCustomer}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers?.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.firstName} {customer.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {messageType === 'template' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Template</label>
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="welcome">Welcome Message</SelectItem>
                      <SelectItem value="followup">Follow Up</SelectItem>
                      <SelectItem value="support">Support</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <Textarea
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Type your message here..."
                  className="h-32"
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" type="button">
                  <Paperclip className="w-4 h-4 mr-2" />
                  Attach
                </Button>
                <Button
                  type="button"
                  onClick={handleSendMessage}
                  disabled={sendMessageMutation.isPending}
                >
                  {sendMessageMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <FaWhatsapp className="w-4 h-4 mr-2" />
                      Send Message
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Recent Messages</CardTitle>
          </CardHeader>
          <CardContent>
            {messages && messages.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Message Preview</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {messages.map((message) => (
                    <TableRow key={message.id}>
                      <TableCell>{message.recipientName}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getTypeBadgeClass(message.messageType)}`}>
                          {message.messageType}
                        </span>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">
                        {message.messagePreview}
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeClass(message.status)}`}>
                          {message.status === "delivered" && <Check className="w-3 h-3 mr-1" />}
                          {message.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="link" className="text-primary h-auto p-0">
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-gray-500 text-center py-6">No WhatsApp messages yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}