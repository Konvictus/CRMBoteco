import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Loader2, Search, Filter, Edit, Mail, Trash2 } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import { Customer } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout/layout";
import CustomerForm from "@/components/customers/customer-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function CustomersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [customerFormOpen, setCustomerFormOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  const { toast } = useToast();

  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const deleteCustomerMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/customers/${id}`);
      return id;
    },
    onSuccess: (id) => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      toast({
        title: "Cliente excluído",
        description: "O cliente foi excluído com sucesso.",
      });
      setCustomerToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Falha ao excluir cliente. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  const filteredCustomers = customers
    ? customers.filter((customer) => {
        const matchesSearch = 
          (customer.firstName + " " + customer.lastName).toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.phone.includes(searchTerm);
        
        const matchesStatus = statusFilter === "all" || customer.status === statusFilter;
        
        return matchesSearch && matchesStatus;
      })
    : [];

  function handleEdit(customer: Customer) {
    setEditingCustomer(customer);
    setCustomerFormOpen(true);
  }

  function handleAddNew() {
    setEditingCustomer(null);
    setCustomerFormOpen(true);
  }

  function handleFormClose() {
    setCustomerFormOpen(false);
    setEditingCustomer(null);
  }

  function handleDeleteCustomer(customer: Customer) {
    setCustomerToDelete(customer);
  }

  function confirmDeleteCustomer() {
    if (customerToDelete) {
      deleteCustomerMutation.mutate(customerToDelete.id);
    }
  }

  function getInitials(firstName: string, lastName: string) {
    return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase();
  }

  function getStatusBadgeClass(status: string) {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "inactive":
        return "bg-gray-100 text-gray-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  }

  function getRandomBgColor(name: string) {
    const colors = [
      "bg-primary-100 text-primary-700",
      "bg-blue-100 text-blue-700",
      "bg-purple-100 text-purple-700",
      "bg-green-100 text-green-700",
      "bg-yellow-100 text-yellow-700",
      "bg-indigo-100 text-indigo-700",
    ];
    
    // Use a hash of the name to select a color
    const index = name.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) % colors.length;
    return colors[index];
  }

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Clientes</h1>
          <p className="text-gray-600">Gerencie seu banco de dados de clientes</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button className="flex items-center" onClick={handleAddNew}>
            <span className="mr-2">+</span> Adicionar Cliente
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar clientes..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex space-x-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="active">Ativos</SelectItem>
                <SelectItem value="inactive">Inativos</SelectItem>
                <SelectItem value="pending">Pendentes</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Telefone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Último Contato</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.length > 0 ? (
                  filteredCustomers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-10 w-10 flex-shrink-0">
                            <span className={`h-10 w-10 rounded-full ${getRandomBgColor(customer.firstName)} flex items-center justify-center font-medium`}>
                              {getInitials(customer.firstName, customer.lastName)}
                            </span>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {customer.firstName} {customer.lastName}
                            </div>
                            <div className="text-sm text-gray-500">
                              ID do Cliente: #{customer.id}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{customer.email}</TableCell>
                      <TableCell>{customer.phone}</TableCell>
                      <TableCell>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(customer.status)}`}>
                          {customer.status === 'active' ? 'Ativo' : 
                           customer.status === 'inactive' ? 'Inativo' : 
                           customer.status === 'pending' ? 'Pendente' : 
                           customer.status.charAt(0).toUpperCase() + customer.status.slice(1)}
                        </span>
                      </TableCell>
                      <TableCell>
                        {customer.lastContact
                          ? new Date(customer.lastContact).toLocaleDateString()
                          : "N/A"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(customer)}>
                            <Edit className="h-4 w-4 text-primary-600" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <FaWhatsapp className="h-4 w-4 text-green-600" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Mail className="h-4 w-4 text-gray-600" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleDeleteCustomer(customer)}
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                      {searchTerm || statusFilter !== "all"
                        ? "Nenhum cliente encontrado. Tente ajustar seus filtros."
                        : "Nenhum cliente cadastrado. Adicione seu primeiro cliente clicando em 'Adicionar Cliente'."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
        
        {!isLoading && filteredCustomers.length > 0 && (
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200">
            <div className="flex-1 flex justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Exibindo <span className="font-medium">1</span> a{" "}
                  <span className="font-medium">{filteredCustomers.length}</span> de{" "}
                  <span className="font-medium">{filteredCustomers.length}</span> resultados
                </p>
              </div>
              {/* We could add pagination controls here if needed */}
            </div>
          </div>
        )}
      </div>

      <Dialog open={customerFormOpen} onOpenChange={setCustomerFormOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingCustomer ? "Editar Cliente" : "Adicionar Novo Cliente"}
            </DialogTitle>
          </DialogHeader>
          <CustomerForm 
            customer={editingCustomer}
            onClose={handleFormClose}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog 
        open={customerToDelete !== null} 
        onOpenChange={(open) => !open && setCustomerToDelete(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
            <AlertDialogDescription>
              Isso excluirá permanentemente o registro do cliente {customerToDelete?.firstName} {customerToDelete?.lastName} 
              e não poderá ser desfeito.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDeleteCustomer}
              className="bg-red-600 hover:bg-red-700"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
