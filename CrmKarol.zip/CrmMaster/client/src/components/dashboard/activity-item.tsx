import { Activity } from "@shared/schema";
import {
  UserPlus,
  Send,
  BarChart,
  Import,
  FileUp,
} from "lucide-react";
import { FaWhatsapp, FaInstagram } from "react-icons/fa";

interface ActivityItemProps {
  activity: Activity;
}

export default function ActivityItem({ activity }: ActivityItemProps) {
  const getActivityIcon = () => {
    switch (activity.type) {
      case "new_customer":
        return <UserPlus className="text-primary-500" />;
      case "campaign":
        return <Send className="text-secondary-500" />;
      case "whatsapp":
        return <FaWhatsapp className="text-green-500" />;
      case "instagram":
        return <FaInstagram className="text-purple-500" />;
      case "import":
        return <Import className="text-blue-500" />;
      case "export":
        return <FileUp className="text-orange-500" />;
      default:
        return <BarChart className="text-gray-500" />;
    }
  };

  const formatTime = (date: Date | null) => {
    if (!date) return "Unknown time";
    
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days}d ago`;
    } else if (hours > 0) {
      return `${hours}h ago`;
    } else if (minutes > 0) {
      return `${minutes}m ago`;
    } else {
      return "Just now";
    }
  };

  return (
    <li className="py-3">
      <div className="flex space-x-3">
        <div className="flex-shrink-0">
          {getActivityIcon()}
        </div>
        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">
              {activity.type
                .replace(/_/g, " ")
                .split(" ")
                .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                .join(" ")}
            </h3>
            <p className="text-xs text-gray-500">
              {formatTime(activity.timestamp)}
            </p>
          </div>
          <p className="text-sm text-gray-600">{activity.description}</p>
        </div>
      </div>
    </li>
  );
}
