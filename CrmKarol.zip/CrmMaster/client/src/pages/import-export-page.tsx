import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Loader2, UploadCloud, Download } from "lucide-react";
import { ImportExportLog } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ImportExportPage() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [exportFormat, setExportFormat] = useState("csv");
  const [exportType, setExportType] = useState("all");
  const [importOptions, setImportOptions] = useState({
    overwrite: false,
    sendWelcome: false,
  });
  const { toast } = useToast();

  const { data: logs, isLoading: isLoadingLogs } = useQuery<ImportExportLog[]>({
    queryKey: ["/api/importexport/logs"],
  });

  const importMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      // Usando apiRequest para padronização e consistência
      // Mas como estamos enviando um FormData, precisamos usar o fetch diretamente
      const res = await fetch("/api/import", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to import file");
      }
      
      return await res.json();
    },
    onSuccess: (data) => {
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      toast({
        title: "Import Successful",
        description: data.message || "Customers imported successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/importexport/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import customers",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    setSelectedFile(file);
  };

  const handleImport = () => {
    if (!selectedFile) {
      toast({
        title: "No File Selected",
        description: "Please select a file to import",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("options", JSON.stringify(importOptions));
    
    importMutation.mutate(formData);
  };

  const handleExport = () => {
    try {
      const params = new URLSearchParams({
        format: exportFormat,
        type: exportType,
      });
      
      // Usando window.open em vez de window.location para permitir que a página continue funcionando
      // e para evitar problemas de navegação
      const exportWindow = window.open(`/api/export?${params.toString()}`, '_blank');
      
      // Fechamos a janela se não for null - algumas vezes os navegadores podem bloquear isso
      if (exportWindow) {
        setTimeout(() => {
          exportWindow.close();
        }, 500);
      }
      
      toast({
        title: "Export Started",
        description: "Your file will download shortly",
      });
      
      // The logs will be updated by the server, so we can refetch after a delay
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/importexport/logs"] });
      }, 2000);
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error during the export process",
        variant: "destructive",
      });
    }
  };

  const handleFileDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    
    if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      setSelectedFile(event.dataTransfer.files[0]);
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "complete":
        return "bg-green-100 text-green-800";
      case "processing":
        return "bg-blue-100 text-blue-800";
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeBadgeClass = (type: string) => {
    return type === "import" 
      ? "bg-blue-100 text-blue-800" 
      : "bg-green-100 text-green-800";
  };

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Import & Export</h1>
        <p className="text-gray-600">Transfer customer data between your CRM and spreadsheets</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center space-y-0 pb-2">
            <UploadCloud className="h-5 w-5 text-primary mr-2" />
            <CardTitle className="text-lg font-medium">Import Customers</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-6">Upload a spreadsheet file to add multiple customers at once.</p>
            
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center"
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleFileDrop}
            >
              <div className="mx-auto">
                <UploadCloud className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 mb-2">
                  {selectedFile ? selectedFile.name : "Drag and drop your file here, or"}
                </p>
                <Label
                  htmlFor="file-upload"
                  className="bg-primary text-white py-2 px-4 rounded-lg hover:bg-primary/90 transition cursor-pointer inline-block"
                >
                  Browse Files
                </Label>
                <input
                  id="file-upload"
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileChange}
                />
                <p className="text-xs text-gray-500 mt-2">Supports: .csv, .xlsx, .xls (max 10MB)</p>
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-900 mb-2">Import Options</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="overwrite" 
                    checked={importOptions.overwrite}
                    onCheckedChange={(checked) => 
                      setImportOptions({ ...importOptions, overwrite: !!checked })
                    }
                  />
                  <Label htmlFor="overwrite" className="text-sm text-gray-700">
                    Overwrite existing customers with matching email
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="send-welcome" 
                    checked={importOptions.sendWelcome}
                    onCheckedChange={(checked) => 
                      setImportOptions({ ...importOptions, sendWelcome: !!checked })
                    }
                  />
                  <Label htmlFor="send-welcome" className="text-sm text-gray-700">
                    Send welcome email to new customers
                  </Label>
                </div>
              </div>
            </div>
            
            <Button 
              className="w-full mt-6" 
              onClick={handleImport}
              disabled={!selectedFile || importMutation.isPending}
            >
              {importMutation.isPending ? (
                <span className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Importing...
                </span>
              ) : (
                "Start Import"
              )}
            </Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center space-y-0 pb-2">
            <Download className="h-5 w-5 text-green-600 mr-2" />
            <CardTitle className="text-lg font-medium">Export Customers</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-6">Download your customer data as a spreadsheet file.</p>
            
            <RadioGroup 
              value={exportType} 
              onValueChange={setExportType}
              className="space-y-4"
            >
              <div className="border border-gray-300 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="all" id="export-all" />
                    <Label htmlFor="export-all" className="text-sm font-medium text-gray-700">
                      All Customers
                    </Label>
                  </div>
                  <span className="text-xs text-gray-500">All records</span>
                </div>
              </div>
              
              <div className="border border-gray-300 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="active" id="export-active" />
                    <Label htmlFor="export-active" className="text-sm font-medium text-gray-700">
                      Active Customers Only
                    </Label>
                  </div>
                  <span className="text-xs text-gray-500">Active records</span>
                </div>
              </div>
            </RadioGroup>
            
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-900 mb-2">Export Format</h3>
              <RadioGroup 
                value={exportFormat} 
                onValueChange={setExportFormat}
                className="flex space-x-6"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem 
                    value="csv" 
                    id="format-csv" 
                  />
                  <Label htmlFor="format-csv" className="text-sm text-gray-700">
                    CSV
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem 
                    value="xlsx" 
                    id="format-xlsx" 
                  />
                  <Label htmlFor="format-xlsx" className="text-sm text-gray-700">
                    Excel (XLSX)
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            <Button 
              className="w-full mt-6 bg-green-600 hover:bg-green-700 flex items-center justify-center"
              onClick={handleExport}
            >
              <Download className="mr-2 h-4 w-4" /> 
              Export Data
            </Button>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Import/Export History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingLogs ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : logs && logs.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>File Name</TableHead>
                  <TableHead>Records</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      {log.timestamp ? new Date(log.timestamp).toLocaleString() : "N/A"}
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getTypeBadgeClass(log.type)}`}>
                        {log.type.charAt(0).toUpperCase() + log.type.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell>{log.fileName}</TableCell>
                    <TableCell>{log.recordCount}</TableCell>
                    <TableCell>
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(log.status)}`}>
                        {log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      {log.type === "export" ? (
                        <Button 
                          variant="link" 
                          className="text-primary h-auto p-0"
                          onClick={() => {
                            const params = new URLSearchParams({
                              format: log.fileName.endsWith('.xlsx') ? 'xlsx' : 'csv',
                              type: 'all',
                              logId: log.id.toString()
                            });
                            
                            window.open(`/api/export?${params.toString()}`, '_blank');
                          }}
                        >
                          Download
                        </Button>
                      ) : (
                        <Button variant="link" className="text-primary h-auto p-0">
                          Details
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-gray-500 text-center py-6">No import or export history yet</p>
          )}
        </CardContent>
      </Card>
    </Layout>
  );
}
