import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Loader2, PlusCircle, Settings, BarChart } from "lucide-react";
import { FaInstagram } from "react-icons/fa";
import { Customer, MessageLog } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Mock images for Instagram posts - note these are placeholders for the app structure
const INSTAGRAM_POSTS = [
  {
    id: 1,
    url: "https://via.placeholder.com/500x500.png?text=Product+Image+1",
    likes: 126,
    comments: 14
  },
  {
    id: 2,
    url: "https://via.placeholder.com/500x500.png?text=Product+Image+2",
    likes: 203,
    comments: 23
  },
  {
    id: 3,
    url: "https://via.placeholder.com/500x500.png?text=Product+Image+3",
    likes: 178,
    comments: 19
  }
];

export default function InstagramPage() {
  const { toast } = useToast();

  const { data: messages, isLoading: isLoadingMessages } = useQuery<MessageLog[]>({
    queryKey: ["/api/instagram/messages"],
  });

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "replied":
        return "bg-green-100 text-green-800";
      case "unread":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Instagram Integration</h1>
        <p className="text-gray-600">Manage your Instagram business account and monitor engagement</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center space-y-0 pb-2">
            <FaInstagram className="h-5 w-5 text-purple-600 mr-2" />
            <CardTitle className="text-lg font-medium">Instagram Business</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-gray-600 mb-4">Account Status</div>
            
            <div className="border border-purple-200 rounded-lg p-4 bg-purple-50 mb-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 text-purple-600">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-purple-800">Connected</h3>
                  <p className="mt-1 text-sm text-purple-700">Your Instagram business account is connected and synced.</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-center mb-6">
              <div className="text-center">
                <div className="h-20 w-20 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-bold text-xl mx-auto">
                  IB
                </div>
                <h3 className="mt-2 text-lg font-medium text-gray-900">@connectcrm</h3>
                <p className="text-sm text-gray-600">Business Account</p>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-center mb-6">
              <div>
                <div className="text-xl font-bold text-gray-900">1,248</div>
                <div className="text-sm text-gray-600">Posts</div>
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">5.4K</div>
                <div className="text-sm text-gray-600">Followers</div>
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">528</div>
                <div className="text-sm text-gray-600">Following</div>
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-6">
              <Button variant="link" className="p-0 h-auto text-purple-600 flex items-center">
                <Settings className="mr-2 h-4 w-4" /> Manage Instagram Settings
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">Recent Posts</CardTitle>
            <Button variant="ghost" className="text-purple-600 flex items-center">
              <PlusCircle className="mr-2 h-4 w-4" /> Create Post
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              {INSTAGRAM_POSTS.map((post) => (
                <div key={post.id} className="relative group">
                  <div className="w-full h-40 bg-gray-200 rounded-lg flex items-center justify-center">
                    <FaInstagram className="h-10 w-10 text-gray-400" />
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                    <div className="text-white text-center p-2">
                      <div className="flex space-x-4">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                          </svg>
                          <span>{post.likes}</span>
                        </div>
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                          </svg>
                          <span>{post.comments}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-200 pt-6">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Performance Insights</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-700">Engagement Rate</h3>
                    <span className="text-green-600 text-sm font-medium">+5.2%</span>
                  </div>
                  <div className="h-12 bg-gray-200 rounded flex items-end">
                    <div className="bg-purple-500 w-3/5 h-6 rounded"></div>
                    <div className="bg-purple-500 w-2/5 h-8 rounded"></div>
                    <div className="bg-purple-500 w-4/5 h-10 rounded"></div>
                    <div className="bg-purple-500 w-3/4 h-12 rounded"></div>
                    <div className="bg-purple-500 w-7/12 h-9 rounded"></div>
                    <div className="bg-purple-500 w-2/3 h-11 rounded"></div>
                    <div className="bg-purple-500 w-5/6 h-7 rounded"></div>
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                    <span>Sun</span>
                  </div>
                </div>
                
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-700">Follower Growth</h3>
                    <span className="text-green-600 text-sm font-medium">+124 this week</span>
                  </div>
                  <div className="h-12 bg-gray-200 rounded flex items-end">
                    <div className="bg-primary w-1/4 h-4 rounded"></div>
                    <div className="bg-primary w-1/3 h-6 rounded"></div>
                    <div className="bg-primary w-2/5 h-8 rounded"></div>
                    <div className="bg-primary w-1/2 h-7 rounded"></div>
                    <div className="bg-primary w-3/5 h-9 rounded"></div>
                    <div className="bg-primary w-2/3 h-10 rounded"></div>
                    <div className="bg-primary w-3/4 h-12 rounded"></div>
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                    <span>Sun</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Instagram Direct Messages</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingMessages ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : messages && messages.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>From</TableHead>
                  <TableHead>Message Preview</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {messages.map((message) => (
                  <TableRow key={message.id}>
                    <TableCell>
                      {new Date(message.timestamp).toLocaleString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                        hour12: true,
                        month: "short",
                        day: "numeric",
                      })}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="h-8 w-8 flex-shrink-0">
                          <span className={`h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-medium`}>
                            {message.recipientName.substring(0, 2).toUpperCase()}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{message.recipientName}</div>
                          <div className="text-xs text-gray-500">{message.recipientId}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">
                      {message.messagePreview}
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(message.status)}`}>
                        {message.status.charAt(0).toUpperCase() + message.status.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="link" className="text-purple-600 h-auto p-0">
                        {message.status === "unread" ? "Reply" : "View"}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-gray-500 text-center py-6">No Instagram messages yet</p>
          )}
        </CardContent>
      </Card>
    </Layout>
  );
}
