import { ArrowUp } from "lucide-react";
import { FaUsers, FaBullhorn, FaChartLine } from "react-icons/fa";
import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: number | string;
  icon: "users" | "bullhorn" | "chart-line";
  change: number;
  changeText: string;
  color: "primary" | "secondary" | "success";
}

export default function StatsCard({
  title,
  value,
  icon,
  change,
  changeText,
  color,
}: StatsCardProps) {
  const getIconComponent = () => {
    switch (icon) {
      case "users":
        return <FaUsers className="text-xl" />;
      case "bullhorn":
        return <FaBullhorn className="text-xl" />;
      case "chart-line":
        return <FaChartLine className="text-xl" />;
      default:
        return null;
    }
  };

  const getColorClasses = () => {
    switch (color) {
      case "primary":
        return {
          bg: "bg-primary-100",
          text: "text-primary-600",
          change: "text-green-600",
        };
      case "secondary":
        return {
          bg: "bg-purple-100",
          text: "text-purple-600",
          change: "text-green-600",
        };
      case "success":
        return {
          bg: "bg-green-100",
          text: "text-green-600",
          change: "text-green-600",
        };
      default:
        return {
          bg: "bg-gray-100",
          text: "text-gray-600",
          change: "text-green-600",
        };
    }
  };

  const colorClasses = getColorClasses();

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center">
          <div className={`p-3 rounded-full ${colorClasses.bg} ${colorClasses.text}`}>
            {getIconComponent()}
          </div>
          <div className="ml-4">
            <h2 className="text-gray-500 text-sm font-medium">{title}</h2>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center text-sm">
            <span className={`${colorClasses.change} font-medium flex items-center`}>
              <ArrowUp className="mr-1 h-4 w-4" /> {change}
              {typeof change === 'number' && !title.includes('Rate') && '%'}
            </span>
            <span className="text-gray-500 ml-2">{changeText}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
