import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import CustomersPage from "@/pages/customers-page";
import ImportExportPage from "@/pages/import-export-page";
import WhatsAppPage from "@/pages/whatsapp-page";
import InstagramPage from "@/pages/instagram-page";
import SettingsPage from "@/pages/settings-page";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/customers" component={CustomersPage} />
      <ProtectedRoute path="/import-export" component={ImportExportPage} />
      <ProtectedRoute path="/whatsapp" component={WhatsAppPage} />
      <ProtectedRoute path="/instagram" component={InstagramPage} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      <Route path="/auth">
        <AuthPage />
      </Route>
      <Route path="/:rest*">
        <NotFound />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
