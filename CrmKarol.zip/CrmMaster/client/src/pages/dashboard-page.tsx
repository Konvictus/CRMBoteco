import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import Layout from "@/components/layout/layout";
import StatsCard from "@/components/dashboard/stats-card";
import ActivityItem from "@/components/dashboard/activity-item";
import QuickAction from "@/components/dashboard/quick-action";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Activity } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();
  
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
  });
  
  const { data: activities, isLoading: isLoadingActivities } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.name || user?.username}! Here's your overview</p>
      </div>

      {isLoadingStats ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          <StatsCard
            title="Total Customers"
            value={stats?.totalCustomers || 0}
            icon="users"
            change={12}
            changeText="from last month"
            color="primary"
          />
          <StatsCard
            title="Active Campaigns"
            value={stats?.activeCampaigns || 0}
            icon="bullhorn"
            change={3}
            changeText="from last month"
            color="secondary"
          />
          <StatsCard
            title="Engagement Rate"
            value={`${stats?.engagementRate || 0}%`}
            icon="chart-line"
            change={7}
            changeText="from last month"
            color="success"
          />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Recent Activities</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingActivities ? (
              <div className="flex justify-center py-6">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : activities && activities.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {activities.map((activity) => (
                  <ActivityItem key={activity.id} activity={activity} />
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-6">No recent activities</p>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <QuickAction
              href="/customers"
              icon="user-plus"
              color="primary"
              label="Add New Customer"
            />
            <QuickAction
              href="/import-export"
              icon="file-import"
              color="success"
              label="Import Contacts"
            />
            <QuickAction
              href="/whatsapp"
              icon="whatsapp"
              color="success"
              label="Send WhatsApp Campaign"
            />
            <QuickAction
              href="/instagram"
              icon="instagram"
              color="secondary"
              label="Instagram Engagement"
            />
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
