import { Link } from "wouter";
import { FaUserPlus, FaFileImport, FaWhatsapp, FaInstagram } from "react-icons/fa";

interface QuickActionProps {
  href: string;
  icon: "user-plus" | "file-import" | "whatsapp" | "instagram";
  color: "primary" | "success" | "secondary";
  label: string;
}

export default function QuickAction({ href, icon, color, label }: QuickActionProps) {
  const getIconComponent = () => {
    switch (icon) {
      case "user-plus":
        return <FaUserPlus />;
      case "file-import":
        return <FaFileImport />;
      case "whatsapp":
        return <FaWhatsapp />;
      case "instagram":
        return <FaInstagram />;
      default:
        return null;
    }
  };

  const getColorClasses = () => {
    switch (color) {
      case "primary":
        return {
          bg: "bg-primary-100",
          text: "text-primary-600",
        };
      case "success":
        return {
          bg: "bg-green-100",
          text: "text-green-600",
        };
      case "secondary":
        return {
          bg: "bg-purple-100",
          text: "text-secondary-600",
        };
      default:
        return {
          bg: "bg-gray-100",
          text: "text-gray-600",
        };
    }
  };

  const colorClasses = getColorClasses();

  return (
    <Link href={href}>
      <a className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
        <div className={`p-2 rounded-full ${colorClasses.bg} ${colorClasses.text}`}>
          {getIconComponent()}
        </div>
        <div className="ml-3">
          <p className="text-sm font-medium text-gray-900">{label}</p>
        </div>
      </a>
    </Link>
  );
}
