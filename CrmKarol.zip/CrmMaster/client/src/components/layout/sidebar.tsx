import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  ChartPie, 
  Users, 
  FileSpreadsheet, 
  Settings, 
  Menu, 
  X 
} from "lucide-react";
import { FaWhatsapp, FaInstagram } from "react-icons/fa";

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(false);
  
  // Close sidebar when changing route on mobile
  useEffect(() => {
    if (isMobile) {
      setIsOpen(false);
    }
  }, [location, isMobile]);

  // Always show sidebar on desktop
  useEffect(() => {
    if (!isMobile) {
      setIsOpen(true);
    }
  }, [isMobile]);

  const navItems = [
    {
      title: "Painel",
      icon: <ChartPie className="w-5 h-5" />,
      href: "/",
    },
    {
      title: "Clientes",
      icon: <Users className="w-5 h-5" />,
      href: "/customers",
    },
    {
      title: "Importar/Exportar",
      icon: <FileSpreadsheet className="w-5 h-5" />,
      href: "/import-export",
    },
    {
      title: "WhatsApp",
      icon: <FaWhatsapp className="w-5 h-5" />,
      href: "/whatsapp",
    },
    {
      title: "Instagram",
      icon: <FaInstagram className="w-5 h-5" />,
      href: "/instagram",
    },
    {
      title: "Configurações",
      icon: <Settings className="w-5 h-5" />,
      href: "/settings",
    },
  ];

  return (
    <>
      {/* Mobile Toggle Button */}
      {isMobile && (
        <div className="fixed top-4 left-4 z-50">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(!isOpen)}
            className="text-gray-500 hover:text-gray-700"
          >
            {isOpen ? <X /> : <Menu />}
          </Button>
        </div>
      )}
      
      {/* Sidebar */}
      <div 
        className={`${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } bg-gray-900 text-white w-64 flex-shrink-0 fixed md:sticky top-0 h-screen transition-transform duration-200 ease-in-out z-40 md:translate-x-0 ${className}`}
      >
        <div className="p-4 flex items-center justify-between border-b border-gray-800">
          <h1 className="text-xl font-bold">GestãoCRM</h1>
          {isMobile && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </Button>
          )}
        </div>
        
        <div className="overflow-y-auto flex-grow">
          <nav className="mt-5 px-2 space-y-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div
                    className={`${
                      isActive
                        ? "bg-gray-800 text-white"
                        : "text-gray-300 hover:bg-gray-700 hover:text-white"
                    } group flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer`}
                  >
                    {item.icon}
                    <span className="ml-3">{item.title}</span>
                  </div>
                </Link>
              );
            })}
          </nav>
        </div>
        
        <div className="border-t border-gray-800 p-4">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium">
              {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-white">
                {user?.name || user?.username}
              </p>
              <button 
                onClick={() => logoutMutation.mutate()}
                className="text-xs text-gray-400 hover:text-gray-200"
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Backdrop for mobile */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
